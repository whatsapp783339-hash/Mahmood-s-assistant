# Mahmood Assistance

An intelligent Android assistant app integrated with the **Gemini API** and built to control device tasks like flashlight, WhatsApp messaging, web searches, alarms, and accessibility/screen reading features without any time limits.

## Features
- **Gemini AI Integration**: Uses Google Gemini API for intelligent conversational responses.
- **Device Control**: Flashlight toggle, alarm setting, web browsing.
- **Automation & Communication**: Direct WhatsApp actions via intents.
- **Accessibility**: Screen reading and navigation support.
